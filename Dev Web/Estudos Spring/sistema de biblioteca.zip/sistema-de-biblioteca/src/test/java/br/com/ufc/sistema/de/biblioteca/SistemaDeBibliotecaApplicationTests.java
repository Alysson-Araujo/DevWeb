package br.com.ufc.sistema.de.biblioteca;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SistemaDeBibliotecaApplicationTests {

	@Test
	void contextLoads() {
	}

}
